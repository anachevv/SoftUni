from project.animal import Animal
from project.worker import Worker


class Zoo:

    def __init__(self, name: str, budget: int, animal_capacity: int, workers_capacity: int):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals = []
        self.workers = []

    def add_animal(self, animal: Animal, price):
        if self.__budget < price:
            return "Not enough budget"
        if len(self.animals) == self.__animal_capacity:
            return "Not enough space for animal"
        self.animals.append(animal)
        self.__budget -= price
        return f"{animal.name} the {animal.__class__.__name__} added to the zoo"

    def hire_worker(self, worker: Worker):
        if len(self.workers) < self.__workers_capacity:
            self.workers.append(worker)
            return f"{worker.name} the {worker.__class__.__name__} hired successfully"
        return "Not enough space for worker"

    def fire_worker(self, worker_name: str):
        for worker in self.workers:
            if worker.name == worker_name:
                self.workers.remove(worker)
                return f"{worker_name} fired successfully"
        return f"There is no {worker_name} in the zoo"

    def pay_workers(self):
        salary_sum = 0
        for worker in self.workers:
            salary_sum += worker.salary
        if salary_sum > self.__budget:
            return "You have no budget to pay your workers. They are unhappy"
        self.__budget -= salary_sum
        return f"You payed your workers. They are happy. Budget left: {self.__budget}"

    def tend_animals(self):
        money_needed = 0
        for animal in self.animals:
            money_needed += animal.money_for_care
        if money_needed > self.__budget:
            return "You have no budget to tend the animals. They are unhappy."
        self.__budget -= money_needed
        return f"You tended all the animals. They are happy. Budget left: {self.__budget}"

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        message = f"You have {len(self.animals)} animals\n"
        message += self.display_info(self.animals, 'Lion')
        message += self.display_info(self.animals, 'Tiger')
        message += self.display_info(self.animals, 'Cheetah')
        return message.strip()

    def workers_status(self):
        result = f'You have {len(self.workers)} workers\n'
        result += self.display_info(self.workers, 'Keeper')
        result += self.display_info(self.workers, 'Caretaker')
        result += self.display_info(self.workers, 'Vet')
        return result.strip()

    def display_info(self, entities, entity_type):
        counter = 0
        message = ""
        for entity in entities:
            if entity.__class__.__name__ == entity_type:
                counter += 1
                message += repr(entity) + '\n'
        return f'----- {counter} {entity_type}s:\n' + message
