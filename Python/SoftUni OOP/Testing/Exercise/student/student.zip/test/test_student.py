from unittest import TestCase, main
from project.student import Student


class TestStudent(TestCase):

    def setUp(self):
        self.student = Student("Ivan")
        self.student_with_course = Student("Jack", {"Python": ["some notes"]})

    def test_initialization(self):
        self.assertEqual("Jack", self.student.name)
        self.assertEqual({}, self.student.courses)
        self.assertEqual({"Python": ["some notes"]}, self.student_with_course.courses)

    def test_already_added_courses(self):
        result = self.student_with_course.enroll("Python", ["more notes"])
        self.assertEqual("Course already added. Notes have been updated.", result)
        expected_notes = ["some notes", "more notes"]
        actual_notes = self.student_with_course.courses["Python"]
        self.assertEqual(expected_notes, actual_notes)

    def test_add_course_notes(self):
        result1 = self.student_with_course.enroll("Java", ["new notes"], "Y")
        result2 = self.student_with_course.enroll("C++", ["new notes"])
        self.assertEqual("Course and course notes have been added.", result1)
        self.assertEqual("Course and course notes have been added.", result2)
        self.assertEqual(["new notes"], self.student_with_course.courses["Java"])
        self.assertEqual(["new notes"], self.student_with_course.courses["C++"])

    def test_without_adding_notes(self):
        result = self.student.enroll("Python", "", "no notes")
        self.assertEqual("Course has been added.", result)
        self.assertEqual([], self.student.courses["Python"])

    def test_add_notes_to_existing_course(self):
        result = self.student_with_course.add_notes("Python", "stuff3")
        self.assertEqual("Notes have been updated", result)
        self.assertEqual(["some notes", "stuff3"], self.student_with_course.courses["Python"])

    def test_add_notes_to_non_existing_course(self):
        with self.assertRaises(Exception) as ex:
            self.student.add_notes("math", "stuff3")
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leaving_existing_course(self):
        result = self.student_with_course.leave_course("Python")
        self.assertEqual("Course has been removed", result)

        with self.assertRaises(KeyError):
            result = self.student_with_course.courses["Python"]

    def test_leaving_non_existing_course(self):
        with self.assertRaises(Exception) as ex:
            self.student.leave_course("Python")

        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))


if __name__ == '__main__':
    main()
