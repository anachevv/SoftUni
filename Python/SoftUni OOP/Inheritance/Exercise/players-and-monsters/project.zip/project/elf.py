from project.hero import Hero


class Elf(Hero):

    def __init__(self, name, level):
        super().__init__(name, level)
