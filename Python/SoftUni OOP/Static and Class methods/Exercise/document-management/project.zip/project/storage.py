from project.category import Category
from project.document import Document
from project.topic import Topic


class Storage:

    def __init__(self):
        self.categories = []
        self.topics = []
        self.documents = []

    def add_category(self, category: Category):
        if not self.find_obj(category, self.categories):
            self.categories.append(category)

    def add_topic(self, topic: Topic):
        if not self.find_obj(topic, self.topics):
            self.topics.append(topic)

    def add_document(self, document: Document):
        if not self.find_obj(document, self.documents):
            self.documents.append(document)

    def edit_category(self, category_id: int, new_name: str):
        for cat in self.categories:
            if cat.id == category_id:
                cat.name = new_name
                break

    def edit_topic(self, topic_id: int, new_topic: str, new_topic_folder: str):
        for curr_topic in self.topics:
            if curr_topic.id == topic_id:
                curr_topic.topic = new_topic
                curr_topic.storage_folder = new_topic_folder
                break

    def edit_document(self, document_id: int, new_file_name: str):
        for doc in self.documents:
            if doc.id == document_id:
                doc.file_name = new_file_name
                break

    def delete_category(self, category_id: int):
        self.del_obj(category_id, self.categories)

    def delete_topic(self, topic_id: int):
        self.del_obj(topic_id, self.topics)

    def delete_document(self, document_id: int):
        self.del_obj(document_id, self.documents)

    def get_document(self, document_id: int):
        for doc in self.documents:
            if doc.id == document_id:
                return doc

    def __repr__(self):
        return '\n'.join([repr(x) for x in self.documents])

    def find_obj(self, obj, obj_list):
        for curr_obj in obj_list:
            if curr_obj.id == obj.id:
                return True
        return False

    def del_obj(self, obj_id, obj_list):
        for curr_obj in obj_list:
            if curr_obj.id == obj_id:
                obj_list.remove(curr_obj)
