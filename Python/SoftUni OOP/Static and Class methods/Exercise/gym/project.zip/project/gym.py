from project.customer import Customer
from project.equipment import Equipment
from project.exercise_plan import ExercisePlan
from project.subscription import Subscription
from project.trainer import Trainer


class Gym:

    def __init__(self):
        self.customers = []
        self.trainers = []
        self.equipment = []
        self.plans = []
        self.subscriptions = []

    def add_customer(self, customer: Customer):
        if not self.find_obj(customer, self.customers):
            self.customers.append(customer)

    def add_trainer(self, trainer: Trainer):
        if not self.find_obj(trainer, self.trainers):
            self.trainers.append(trainer)

    def add_equipment(self, equipment: Equipment):
        if not self.find_obj(equipment, self.equipment):
            self.equipment.append(equipment)

    def add_plan(self, exercise_plan: ExercisePlan):
        plan_is_in = False
        for curr_obj in self.plans:
            if curr_obj.trainer_id == exercise_plan.trainer_id and curr_obj.equipment_id == exercise_plan.equipment_id:
                plan_is_in = True
                break
        if not plan_is_in:
            self.plans.append(exercise_plan)

    def add_subscription(self, subscription: Subscription):
        plan_is_in = False
        for curr_obj in self.subscriptions:
            if curr_obj.customer_id == subscription.customer_id and curr_obj.trainer_id == subscription.trainer_id:
                plan_is_in = True
                break
        if not plan_is_in:
            self.subscriptions.append(subscription)

    def subscription_info(self, subscription_id: int):
        message = "".join(repr(x) for x in self.subscriptions)
        for customer in self.customers:
            for equipment in self.equipment:
                for plan in self.plans:
                    for trainer in self.trainers:
                        if customer.id == subscription_id:
                            message += '\n' + "".join(repr(x) for x in self.customers)
                        if trainer.id == subscription_id:
                            message += '\n' + "".join(repr(x) for x in self.trainers)
                        if equipment.id == subscription_id:
                            message += '\n' + "".join(repr(x) for x in self.equipment)
                        if plan.id == subscription_id:
                            message += '\n' + "".join(repr(x) for x in self.plans)

                        return message

    def find_obj(self, obj, obj_list):
        for curr_obj in obj_list:
            if curr_obj.name == obj.name:
                return True
        return False
