class Player:

    def __init__(self, name: str, health: int, mana: int):
        self.name = name
        self.health = health
        self.mana = mana
        self.skills = {}
        self.guild = "Unaffiliated"

    def add_skill(self, skill: str, mana: int):
        if skill in self.skills:
            return "Skill already added"
        self.skills[skill] = mana
        return f"Skill {skill} added to the collection of the player {self.name}"

    def player_info(self):
        message = f"Name: {self.name}\nGuild: {self.guild}\nHP: {self.health}\nMP: {self.mana}\n"
        for skill, mana in self.skills.items():
            message += f"==={skill} - {mana}" + '\n'
        return message
